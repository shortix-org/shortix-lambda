"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_mock_1 = __importDefault(require("aws-sdk-mock"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const create_url_1 = require("../../handlers/create_url");
const dynamo_1 = require("../../shared/dynamo");
// Must be set before importing handlers if they use it at module level
// But our handler uses it from'../shared/dynamo' which is evaluated on import
process.env.TABLE_NAME = 'TestTable';
process.env.AWS_REGION = 'us-east-1';
process.env.NODE_ENV = 'test';
describe('create_url handler', () => {
    beforeEach(() => {
        (0, dynamo_1.resetDynamoDb)();
        aws_sdk_mock_1.default.setSDKInstance(aws_sdk_1.default);
    });
    afterEach(() => {
        aws_sdk_mock_1.default.restore();
    });
    test('should create a short URL successfully', async () => {
        aws_sdk_mock_1.default.mock('DynamoDB.DocumentClient', 'put', (params, callback) => {
            callback(null, {});
        });
        const event = {
            requestContext: {
                authorizer: {
                    claims: { sub: 'user-123' }
                }
            },
            body: JSON.stringify({ url: 'https://example.com' })
        };
        const result = await (0, create_url_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(201);
        const body = JSON.parse(result.body);
        expect(body.short_code).toBeDefined();
        expect(body.short_code.length).toBe(8);
    });
    test('should return 401 if unauthorized', async () => {
        const event = {
            requestContext: {
                authorizer: {}
            },
            body: JSON.stringify({ url: 'https://example.com' })
        };
        const result = await (0, create_url_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(401);
    });
    test('should return 400 if URL is invalid', async () => {
        const event = {
            requestContext: {
                authorizer: {
                    claims: { sub: 'user-123' }
                }
            },
            body: JSON.stringify({ url: 'not-a-url' })
        };
        const result = await (0, create_url_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body).message).toBe('Invalid URL format');
    });
});
