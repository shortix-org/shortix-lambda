"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_mock_1 = __importDefault(require("aws-sdk-mock"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const get_urls_1 = require("../../handlers/get_urls");
const dynamo_1 = require("../../shared/dynamo");
process.env.TABLE_NAME = 'TestTable';
process.env.AWS_REGION = 'us-east-1';
process.env.NODE_ENV = 'test';
describe('get_urls handler', () => {
    beforeEach(() => {
        (0, dynamo_1.resetDynamoDb)();
        aws_sdk_mock_1.default.setSDKInstance(aws_sdk_1.default);
    });
    afterEach(() => {
        aws_sdk_mock_1.default.restore();
    });
    test('should return list of URLs for a user', async () => {
        const mockItems = [
            { pk: 'URL#1', original_url: 'https://a.com' },
            { pk: 'URL#2', original_url: 'https://b.com' }
        ];
        aws_sdk_mock_1.default.mock('DynamoDB.DocumentClient', 'query', (params, callback) => {
            callback(null, { Items: mockItems });
        });
        const event = {
            requestContext: {
                authorizer: {
                    claims: { sub: 'user-123' }
                }
            }
        };
        const result = await (0, get_urls_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual(mockItems);
    });
});
