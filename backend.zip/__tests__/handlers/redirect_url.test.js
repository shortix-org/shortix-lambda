"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_mock_1 = __importDefault(require("aws-sdk-mock"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const redirect_url_1 = require("../../handlers/redirect_url");
const dynamo_1 = require("../../shared/dynamo");
process.env.TABLE_NAME = 'TestTable';
process.env.AWS_REGION = 'us-east-1';
process.env.NODE_ENV = 'test';
describe('redirect_url handler', () => {
    beforeEach(() => {
        (0, dynamo_1.resetDynamoDb)();
        aws_sdk_mock_1.default.setSDKInstance(aws_sdk_1.default);
    });
    afterEach(() => {
        aws_sdk_mock_1.default.restore();
    });
    test('should redirect if URL found', async () => {
        aws_sdk_mock_1.default.mock('DynamoDB.DocumentClient', 'get', (params, callback) => {
            callback(null, { Item: { original_url: 'https://google.com' } });
        });
        const event = {
            pathParameters: { short_code: 'abc' }
        };
        const result = await (0, redirect_url_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(301);
        expect(result.headers?.Location).toBe('https://google.com');
    });
    test('should return 404 if URL not found', async () => {
        aws_sdk_mock_1.default.mock('DynamoDB.DocumentClient', 'get', (params, callback) => {
            callback(null, {});
        });
        const event = {
            pathParameters: { short_code: 'notfound' }
        };
        const result = await (0, redirect_url_1.handler)(event, {}, () => { });
        if (!result)
            throw new Error('Result is undefined');
        expect(result.statusCode).toBe(404);
    });
});
