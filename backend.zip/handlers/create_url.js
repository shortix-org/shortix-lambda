"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const nanoid_1 = require("nanoid");
const dynamo_1 = require("../shared/dynamo");
const response_1 = require("../shared/response");
const handler = async (event) => {
    try {
        const { body, requestContext } = event;
        const userId = requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, response_1.errorResponse)('Unauthorized', 401);
        }
        if (!body) {
            return (0, response_1.errorResponse)('Missing request body', 400);
        }
        const { url } = JSON.parse(body);
        if (!url) {
            return (0, response_1.errorResponse)('URL is required', 400);
        }
        // Basic URL validation
        try {
            new URL(url);
        }
        catch (e) {
            return (0, response_1.errorResponse)('Invalid URL format', 400);
        }
        const shortCode = (0, nanoid_1.nanoid)(8);
        const createdAt = new Date().toISOString();
        const item = {
            pk: `URL#${shortCode}`,
            sk: 'INFO',
            gsi1_pk: `USER#${userId}`,
            gsi1_sk: createdAt,
            created_at: createdAt,
            original_url: url,
            short_code: shortCode,
            user_id: userId,
            clicks: 0
        };
        await (0, dynamo_1.getDynamoDb)().put({
            TableName: dynamo_1.TABLE_NAME,
            Item: item,
            ConditionExpression: 'attribute_not_exists(pk)'
        }).promise();
        return (0, response_1.successResponse)({
            short_code: shortCode,
            short_url: `${process.env.API_URL}/${shortCode}`,
            created_at: createdAt
        }, 201);
    }
    catch (error) {
        console.error('Error creating URL:', error);
        return (0, response_1.errorResponse)('Internal Server Error');
    }
};
exports.handler = handler;
