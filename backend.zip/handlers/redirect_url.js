"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamo_1 = require("../shared/dynamo");
const response_1 = require("../shared/response");
const handler = async (event) => {
    try {
        const { pathParameters } = event;
        const shortCode = pathParameters?.short_code;
        if (!shortCode) {
            return (0, response_1.errorResponse)('Short code is required', 400);
        }
        const params = {
            TableName: dynamo_1.TABLE_NAME,
            Key: {
                pk: `URL#${shortCode}`,
                sk: 'INFO',
            },
        };
        const result = await (0, dynamo_1.getDynamoDb)().get(params).promise();
        if (!result.Item || !result.Item.original_url) {
            return (0, response_1.errorResponse)('URL not found', 404);
        }
        // Optional: Increment click count async (fire and forget or use stream)
        // For now we just redirect.
        return {
            statusCode: 301,
            headers: {
                'Location': result.Item.original_url,
                'Access-Control-Allow-Origin': '*',
            },
            body: '',
        };
    }
    catch (error) {
        console.error('Error redirecting:', error);
        return (0, response_1.errorResponse)('Internal Server Error');
    }
};
exports.handler = handler;
