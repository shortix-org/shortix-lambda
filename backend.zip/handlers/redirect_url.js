"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME || '';
const handler = async (event) => {
    try {
        if (!TABLE_NAME) {
            throw new Error('TABLE_NAME environment variable is not set');
        }
        const { pathParameters } = event;
        const shortCode = pathParameters?.short_code;
        if (!shortCode) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Short code is required' }),
                headers: { 'Access-Control-Allow-Origin': '*' },
            };
        }
        const params = {
            TableName: TABLE_NAME,
            Key: {
                pk: `URL#${shortCode}`,
                sk: 'INFO',
            },
        };
        const result = await dynamoDb.get(params).promise();
        if (!result.Item || !result.Item.original_url) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'URL not found' }),
                headers: { 'Access-Control-Allow-Origin': '*' },
            };
        }
        // Optional: Increment click count async (fire and forget or use stream)
        // For now we just redirect.
        return {
            statusCode: 301,
            headers: {
                'Location': result.Item.original_url,
                'Access-Control-Allow-Origin': '*',
            },
            body: '',
        };
    }
    catch (error) {
        console.error('Error redirecting:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error' }),
            headers: { 'Access-Control-Allow-Origin': '*' },
        };
    }
};
exports.handler = handler;
