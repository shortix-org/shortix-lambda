"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamo_1 = require("../shared/dynamo");
const response_1 = require("../shared/response");
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, response_1.errorResponse)('Unauthorized', 401);
        }
        const params = {
            TableName: dynamo_1.TABLE_NAME,
            IndexName: 'UserUrlsIndex',
            KeyConditionExpression: 'gsi1_pk = :userId',
            ExpressionAttributeValues: {
                ':userId': `USER#${userId}`,
            },
            ScanIndexForward: false, // Sort by created_at descending (latest first)
        };
        const result = await dynamo_1.dynamoDb.query(params).promise();
        return (0, response_1.successResponse)(result.Items || []);
    }
    catch (error) {
        console.error('Error fetching URLs:', error);
        return (0, response_1.errorResponse)('Internal Server Error');
    }
};
exports.handler = handler;
