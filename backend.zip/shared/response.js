"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorResponse = exports.successResponse = exports.createResponse = void 0;
const createResponse = (statusCode, body) => {
    return {
        statusCode,
        body: JSON.stringify(body),
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
        },
    };
};
exports.createResponse = createResponse;
const successResponse = (body, statusCode = 200) => (0, exports.createResponse)(statusCode, body);
exports.successResponse = successResponse;
const errorResponse = (message, statusCode = 500) => (0, exports.createResponse)(statusCode, { message });
exports.errorResponse = errorResponse;
