"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TABLE_NAME = exports.dynamoDb = void 0;
const aws_sdk_1 = require("aws-sdk");
exports.dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
exports.TABLE_NAME = process.env.TABLE_NAME || '';
if (!exports.TABLE_NAME) {
    console.warn('TABLE_NAME environment variable is not set');
}
